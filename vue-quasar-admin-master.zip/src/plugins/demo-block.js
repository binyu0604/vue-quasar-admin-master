import DemoBlock from '@/components/DemoBlock.vue'

export default ({ Vue }) => {
    Vue.component('demo-block', DemoBlock);
}