<template>
     <q-page class="flex flex-center">
        <img alt="Quasar logo" src="~assets/quasar-logo-full.svg">
    </q-page>
</template>

<script>
export default {
    name: 'comment',
    data(){
        return{
            list:[1,2,3,4,5,6]
        }
    },
    created(){
        
    }
};
</script>